# ============================================================
# GSE98923 -> subset balanceado de 54 muestras -> CEMiTool
# Cabernet Sauvignon vs Pinot noir
# FruitSet / Veraison / Harvest, 2012-2014, 3 replicas por grupo
# ============================================================

# -----------------------------
# 0) Configuracion
# -----------------------------
GSE_ID <- "GSE98923"
BASE_DIR <- "GSE98923_CEMiTool_baseline"
META_FILE <- "GSE98923_selection_54.tsv"

dir.create(BASE_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(BASE_DIR, "geo"), showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(BASE_DIR, "matrices"), showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(BASE_DIR, "cemitool"), showWarnings = FALSE, recursive = TRUE)

# -----------------------------
# 1) Instalar/cargar paquetes
# -----------------------------
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}

needed <- c("GEOquery", "CEMiTool")
to_install <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(to_install) > 0) {
  BiocManager::install(to_install, ask = FALSE, update = FALSE)
}

suppressPackageStartupMessages({
  library(GEOquery)
  library(CEMiTool)
})

# -----------------------------
# 2) Leer el diseno de 54 muestras
# -----------------------------
if (!file.exists(META_FILE)) {
  stop(
    "No encuentro ", META_FILE,
    ". Pon este script y GSE98923_selection_54.tsv en la misma carpeta de trabajo."
  )
}

meta <- read.delim(
  META_FILE,
  sep = "\t",
  header = TRUE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

required_meta <- c(
  "SampleName", "Class", "GSM", "Cultivar", "Year",
  "Stage", "TimePoint", "Replicate"
)
missing_meta <- setdiff(required_meta, colnames(meta))
if (length(missing_meta) > 0) {
  stop("Faltan columnas en metadata: ", paste(missing_meta, collapse = ", "))
}

if (nrow(meta) != 54) {
  stop("Se esperaban 54 muestras y hay ", nrow(meta), ".")
}
if (anyDuplicated(meta$SampleName)) {
  stop("SampleName contiene duplicados.")
}

cat("\nDiseno seleccionado:\n")
print(with(meta, table(Cultivar, Stage, Year)))
cat("\nClases para CEMiTool:\n")
print(table(meta$Class))

# -----------------------------
# 3) Descargar el RPKM procesado oficial de GEO
# -----------------------------
# El registro GSE98923 contiene:
# GSE98923_RPKM_2012-2013-2014_controls.txt.gz
supp_dir <- file.path(BASE_DIR, "geo")

message("\nDescargando/consultando archivos suplementarios de ", GSE_ID, " ...")
GEOquery::getGEOSuppFiles(
  GSE_ID,
  makeDirectory = TRUE,
  baseDir = supp_dir
)

rpkm_candidates <- list.files(
  supp_dir,
  pattern = "GSE98923_RPKM_2012-2013-2014_controls\\.txt\\.gz$",
  full.names = TRUE,
  recursive = TRUE
)

if (length(rpkm_candidates) != 1) {
  stop(
    "No pude identificar de forma unica el archivo RPKM oficial. Encontrados: ",
    paste(rpkm_candidates, collapse = "; ")
  )
}
rpkm_file <- rpkm_candidates[1]
message("Archivo RPKM: ", rpkm_file)

# -----------------------------
# 4) Obtener metadata GEO para mapear GSM <-> Description
# -----------------------------
message("\nDescargando metadata GEO de ", GSE_ID, " ...")
gse_list <- GEOquery::getGEO(GSE_ID, GSEMatrix = TRUE, getGPL = FALSE)
if (length(gse_list) < 1) stop("getGEO no devolvio ningun ExpressionSet.")

gse <- gse_list[[1]]
geo_pheno <- Biobase::pData(gse)

# GEOquery suele incluir geo_accession y description.
if ("geo_accession" %in% colnames(geo_pheno)) {
  geo_gsm <- as.character(geo_pheno$geo_accession)
} else {
  geo_gsm <- rownames(geo_pheno)
}

description_cols <- grep(
  "description",
  colnames(geo_pheno),
  ignore.case = TRUE,
  value = TRUE
)

if (length(description_cols) == 0) {
  stop(
    "No encontre una columna 'description' en pData(GSE98923). ",
    "Columnas disponibles: ", paste(colnames(geo_pheno), collapse = ", ")
  )
}

# Elegimos la primera columna de description no vacia por muestra.
get_description <- function(i) {
  vals <- as.character(geo_pheno[i, description_cols, drop = TRUE])
  vals <- vals[!is.na(vals) & nzchar(vals)]
  if (length(vals) == 0) return(NA_character_)
  vals[1]
}

geo_description <- vapply(seq_len(nrow(geo_pheno)), get_description, character(1))

geo_map <- data.frame(
  GSM = geo_gsm,
  Description = geo_description,
  stringsAsFactors = FALSE
)

sel_map <- geo_map[match(meta$GSM, geo_map$GSM), , drop = FALSE]
if (anyNA(sel_map$GSM)) {
  stop(
    "No pude encontrar en GEO estos GSM: ",
    paste(meta$GSM[is.na(sel_map$GSM)], collapse = ", ")
  )
}

# Guardamos el mapping para auditoria/reproducibilidad.
mapping_out <- cbind(meta, GEO_Description = sel_map$Description)
write.table(
  mapping_out,
  file = file.path(BASE_DIR, "GSE98923_selection_54_with_GEO_description.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

# -----------------------------
# 5) Leer matriz oficial y seleccionar exactamente las 54 muestras
# -----------------------------
message("\nLeyendo matriz RPKM oficial ...")
rpkm_raw <- read.delim(
  gzfile(rpkm_file),
  sep = "\t",
  header = TRUE,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

if (ncol(rpkm_raw) < 2) stop("El archivo RPKM no tiene suficientes columnas.")

gene_ids <- as.character(rpkm_raw[[1]])
if (anyNA(gene_ids) || any(!nzchar(gene_ids))) {
  stop("Hay Gene IDs vacios/NA en la primera columna del archivo RPKM.")
}
if (anyDuplicated(gene_ids)) {
  stop(
    "La primera columna contiene Gene IDs duplicados. ",
    "No los agregare automaticamente porque eso cambia el dato biologico."
  )
}

expr_colnames <- colnames(rpkm_raw)[-1]

# Caso A: las columnas del archivo son GSM.
if (all(meta$GSM %in% expr_colnames)) {
  source_cols <- meta$GSM
  names(source_cols) <- meta$GSM

# Caso B: las columnas son el campo Description de GEO (muy comun en este dataset).
} else if (all(sel_map$Description %in% expr_colnames)) {
  source_cols <- sel_map$Description
  names(source_cols) <- meta$GSM

# Caso C: R pudo haber convertido nombres; comprobacion defensiva.
} else if (all(make.names(sel_map$Description) %in% make.names(expr_colnames))) {
  idx <- match(make.names(sel_map$Description), make.names(expr_colnames))
  source_cols <- expr_colnames[idx]
  names(source_cols) <- meta$GSM

} else {
  missing_desc <- sel_map$Description[!sel_map$Description %in% expr_colnames]
  stop(
    "No pude mapear de forma segura las 54 muestras contra las columnas del RPKM.\n",
    "Ejemplos de columnas del RPKM: ",
    paste(head(expr_colnames, 10), collapse = ", "), "\n",
    "Ejemplos de Description faltantes: ",
    paste(head(missing_desc, 10), collapse = ", ")
  )
}

expr_rpkm <- rpkm_raw[, unname(source_cols), drop = FALSE]
colnames(expr_rpkm) <- names(source_cols)
rownames(expr_rpkm) <- gene_ids

# Convertir a numerico sin alterar nombres de muestras.
expr_rpkm[] <- lapply(expr_rpkm, as.numeric)

if (anyNA(as.matrix(expr_rpkm))) {
  stop("La matriz seleccionada contiene NA despues de convertir a numerico.")
}
if (any(!is.finite(as.matrix(expr_rpkm)))) {
  stop("La matriz seleccionada contiene Inf/-Inf.")
}
if (any(as.matrix(expr_rpkm) < 0)) {
  stop("La matriz RPKM contiene valores negativos, lo que no se esperaba.")
}

# Asegurar el orden exacto del archivo de metadata.
expr_rpkm <- expr_rpkm[, meta$SampleName, drop = FALSE]

# -----------------------------
# 6) Guardar dos matrices:
#    A) RPKM exacto
#    B) log2(RPKM + 1) para el CEMiTool baseline
# -----------------------------
write_expression_tsv <- function(mat, path) {
  out <- data.frame(GeneID = rownames(mat), mat, check.names = FALSE)
  write.table(out, path, sep = "\t", quote = FALSE, row.names = FALSE)
}

rpkm_out <- file.path(
  BASE_DIR, "matrices",
  "GSE98923_CEMiTool_expression_54_RPKM.tsv"
)
write_expression_tsv(expr_rpkm, rpkm_out)

expr_log2 <- log2(expr_rpkm + 1)

log2_out <- file.path(
  BASE_DIR, "matrices",
  "GSE98923_CEMiTool_expression_54_log2RPKM.tsv"
)
write_expression_tsv(expr_log2, log2_out)

# El archivo minimo de fenotipos que usa CEMiTool.
annot <- meta[, c("SampleName", "Class")]
phen_out <- file.path(
  BASE_DIR, "matrices",
  "GSE98923_CEMiTool_phenotypes_54.tsv"
)
write.table(
  annot, phen_out,
  sep = "\t", quote = FALSE, row.names = FALSE
)

cat("\nMatriz final:\n")
cat("Genes x muestras (RPKM): ", nrow(expr_rpkm), " x ", ncol(expr_rpkm), "\n", sep = "")
cat("Genes x muestras (log2): ", nrow(expr_log2), " x ", ncol(expr_log2), "\n", sep = "")
stopifnot(identical(colnames(expr_log2), annot$SampleName))

# -----------------------------
# 7) CEMiTool BASELINE
# -----------------------------
# Importante:
# - usamos log2(RPKM + 1), ya normalizado;
# - por eso apply_vst = FALSE;
# - CEMiTool usara las seis clases definidas en Class.
#
# Este es el analisis BASELINE solicitado ahora.
# NO incorpora todavia:
#   * validacion skin-only,
#   * modelo Cultivar*Stage + Year,
#   * re-procesamiento moderno de FASTQ,
#   * las 219 muestras completas.
set.seed(1234)

cem <- CEMiTool::cemitool(
  expr = as.data.frame(expr_log2, check.names = FALSE),
  annot = annot,
  filter = TRUE,
  filter_pval = 0.1,
  apply_vst = FALSE,
  cor_method = "pearson",
  network_type = "unsigned",
  tom_type = "signed",
  merge_similar = TRUE,
  min_ngen = 30,
  plot = TRUE,
  plot_diagnostics = TRUE,
  order_by_class = TRUE,
  verbose = TRUE
)

cem_dir <- file.path(BASE_DIR, "cemitool")
saveRDS(cem, file.path(cem_dir, "GSE98923_CEMiTool_54_baseline.rds"))

# Tablas
CEMiTool::write_files(
  cem,
  directory = file.path(cem_dir, "tables"),
  force = TRUE
)

# Graficos
CEMiTool::save_plots(
  cem,
  "all",
  directory = file.path(cem_dir, "plots")
)

# Reporte HTML
CEMiTool::generate_report(
  cem,
  directory = file.path(cem_dir, "report"),
  output_format = "html_document"
)

# Informacion de sesion para reproducibilidad
writeLines(
  capture.output(sessionInfo()),
  con = file.path(BASE_DIR, "sessionInfo.txt")
)

cat("\n========================================\n")
cat("ANALISIS TERMINADO\n")
cat("========================================\n")
cat("Matriz RPKM: ", rpkm_out, "\n", sep = "")
cat("Matriz log2(RPKM+1): ", log2_out, "\n", sep = "")
cat("Fenotipos: ", phen_out, "\n", sep = "")
cat("Resultados CEMiTool: ", cem_dir, "\n", sep = "")
cat("Objeto RDS: ", file.path(cem_dir, "GSE98923_CEMiTool_54_baseline.rds"), "\n", sep = "")
